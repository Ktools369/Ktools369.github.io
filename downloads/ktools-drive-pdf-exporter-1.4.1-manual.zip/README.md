# KTools Drive PDF Exporter 1.4.1

Chrome Web Store-ready source package. The extension runs only on `drive.google.com`, processes page images locally, and opens `https://ktools369.github.io/` when its toolbar icon or KTools link is selected.

Use only with documents you own or are authorized to save.
