(() => {
  "use strict";

  const CLEAR_COOKIES_MESSAGE = "KTOOLS_CLEAR_STUDOCU_COOKIES";

  function cookieRemovalUrl(cookie) {
    const cleanDomain = cookie.domain.startsWith(".")
      ? cookie.domain.slice(1)
      : cookie.domain;
    const protocol = cookie.secure ? "https:" : "http:";
    return protocol + "//" + cleanDomain + (cookie.path || "/");
  }

  async function clearStudocuCookies() {
    const allCookies = await chrome.cookies.getAll({});
    let count = 0;

    for (const cookie of allCookies) {
      if (!cookie.domain.toLowerCase().includes("studocu")) continue;

      await chrome.cookies.remove({
        url: cookieRemovalUrl(cookie),
        name: cookie.name,
        storeId: cookie.storeId
      });
      count += 1;
    }

    return count;
  }

  chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
    if (message?.type !== CLEAR_COOKIES_MESSAGE) return false;

    clearStudocuCookies()
      .then((count) => sendResponse({ ok: true, count }))
      .catch((error) => sendResponse({
        ok: false,
        error: error?.message || "Could not clear Studocu cookies."
      }));

    return true;
  });
})();
