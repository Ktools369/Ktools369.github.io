(() => {
  "use strict";

  const IDS = {
    root: "ktools-studocu-root",
    toggle: "ktools-studocu-toggle",
    panel: "ktools-studocu-panel",
    status: "ktools-studocu-status",
    progressBar: "ktools-studocu-bar",
    unblurButton: "ktools-studocu-unblur",
    downloadButton: "ktools-studocu-download",
    viewer: "ktools-studocu-viewer",
    toast: "ktools-studocu-toast"
  };

  const state = {
    busy: false,
    originalScrollY: 0
  };

  const CLEAN_PAGE = {
    scaleFactor: 4,
    heightScaleDivisor: 4,
    fallbackWidth: 595.3,
    fallbackHeight: 841.9
  };

  const MESSAGES = {
    clearCookies: "KTOOLS_CLEAR_STUDOCU_COOKIES"
  };

  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

  function unique(nodes) {
    return [...new Set(nodes)];
  }

  function getPageNodes() {
    const pdf2htmlPages = [...document.querySelectorAll(".p2hv .pf")];
    if (pdf2htmlPages.length) return unique(pdf2htmlPages);

    const indexedPages = [...document.querySelectorAll("[data-page-index]")];
    return unique(indexedPages);
  }

  function pageNumber(page, fallbackIndex) {
    const raw = page.getAttribute("data-page-index");
    const parsed = Number(raw);
    return Number.isFinite(parsed) ? parsed + 1 : fallbackIndex + 1;
  }

  function textFrom(value) {
    return String(value || "").toLowerCase();
  }

  function hasRestrictionMarker(page) {
    const markerText = [
      page.className,
      page.getAttribute("data-testid"),
      page.getAttribute("data-test-selector"),
      page.getAttribute("aria-label")
    ].map(textFrom).join(" ");

    if (/blurred|premium-locked|premium_locked|restricted/.test(markerText)) {
      return true;
    }

    const markedDescendant = page.querySelector(
      '[class*="blurred" i], [class*="premium-locked" i], ' +
      '[data-test-selector*="premium" i], [aria-label*="premium" i]'
    );
    if (markedDescendant) return true;

    const inspected = [page, page.querySelector(".page-content"), page.querySelector(".pc")]
      .filter(Boolean);

    return inspected.some((element) => {
      const style = getComputedStyle(element);
      return /blur\(/i.test(style.filter || "") ||
        /blur\(/i.test(style.backdropFilter || "");
    });
  }

  function hasRenderedContent(page) {
    const images = [...page.querySelectorAll("img")];
    const loadedImage = images.some((image) =>
      image.complete && image.naturalWidth > 0 && image.naturalHeight > 0
    );
    const textLength = (page.innerText || "").trim().length;
    return loadedImage || textLength > 20 || page.querySelectorAll("span").length > 3;
  }

  async function waitForStablePage(page) {
    let lastLength = -1;
    let stableChecks = 0;

    for (let attempt = 0; attempt < 30; attempt += 1) {
      const currentLength = page.innerHTML.length;
      if (hasRenderedContent(page)) {
        stableChecks = currentLength === lastLength ? stableChecks + 1 : 0;
        lastLength = currentLength;
        if (stableChecks >= 2) return;
      }
      await sleep(150);
    }
  }

  function stripKToolsUi(clone) {
    clone.querySelectorAll(
      "#" + IDS.root + ", #" + IDS.viewer + ", #" + IDS.toast + ", [data-ktools-ui]"
    ).forEach((element) => element.remove());
  }

  function normalizeCapturedVisibility(root) {
    [root, ...root.querySelectorAll(".page-content, .pc, img")].forEach((element) => {
      element.style.setProperty("filter", "none", "important");
      element.style.setProperty("-webkit-filter", "none", "important");
      element.style.setProperty("backdrop-filter", "none", "important");
      element.style.setProperty("-webkit-backdrop-filter", "none", "important");
      element.style.setProperty("visibility", "visible", "important");
      element.style.setProperty("opacity", "1", "important");
    });

    root.querySelectorAll(".page-content, .pc").forEach((element) => {
      element.style.setProperty("display", "block", "important");
    });
  }

  function copyComputedStyle(
    source,
    target,
    scaleFactor,
    shouldScaleHeight = false,
    shouldScaleWidth = false,
    heightScaleDivisor = 4,
    widthScaleDivisor = 4,
    shouldScaleMargin = false,
    marginScaleDivisor = 4
  ) {
    const computedStyle = getComputedStyle(source);
    const normalProps = [
      "position", "left", "top", "bottom", "right",
      "font-family", "font-weight", "font-style",
      "color", "background-color",
      "text-align", "white-space",
      "display", "visibility", "opacity", "z-index",
      "text-shadow", "unicode-bidi", "font-feature-settings", "padding"
    ];
    const scaleProps = ["font-size", "line-height"];
    let styleString = "";

    normalProps.forEach((prop) => {
      const value = computedStyle.getPropertyValue(prop);
      if (value && value !== "none" && value !== "auto" && value !== "normal") {
        styleString += prop + ": " + value + " !important; ";
      }
    });

    const widthValue = computedStyle.getPropertyValue("width");
    if (widthValue && widthValue !== "none" && widthValue !== "auto") {
      if (shouldScaleWidth) {
        const numValue = parseFloat(widthValue);
        if (!Number.isNaN(numValue) && numValue > 0) {
          const unit = widthValue.replace(numValue.toString(), "");
          styleString += "width: " + (numValue / widthScaleDivisor) + unit + " !important; ";
        } else {
          styleString += "width: " + widthValue + " !important; ";
        }
      } else {
        styleString += "width: " + widthValue + " !important; ";
      }
    }

    const heightValue = computedStyle.getPropertyValue("height");
    if (heightValue && heightValue !== "none" && heightValue !== "auto") {
      if (shouldScaleHeight) {
        const numValue = parseFloat(heightValue);
        if (!Number.isNaN(numValue) && numValue > 0) {
          const unit = heightValue.replace(numValue.toString(), "");
          styleString += "height: " + (numValue / heightScaleDivisor) + unit + " !important; ";
        } else {
          styleString += "height: " + heightValue + " !important; ";
        }
      } else {
        styleString += "height: " + heightValue + " !important; ";
      }
    }

    ["margin-top", "margin-right", "margin-bottom", "margin-left"].forEach((prop) => {
      const value = computedStyle.getPropertyValue(prop);
      if (!value || value === "auto") return;

      const numValue = parseFloat(value);
      if (Number.isNaN(numValue)) return;

      if (shouldScaleMargin && numValue !== 0) {
        const unit = value.replace(numValue.toString(), "");
        styleString += prop + ": " + (numValue / marginScaleDivisor) + unit + " !important; ";
      } else {
        styleString += prop + ": " + value + " !important; ";
      }
    });

    scaleProps.forEach((prop) => {
      const value = computedStyle.getPropertyValue(prop);
      if (value && value !== "none" && value !== "auto" && value !== "normal") {
        const numValue = parseFloat(value);
        if (!Number.isNaN(numValue) && numValue !== 0) {
          const unit = value.replace(numValue.toString(), "");
          styleString += prop + ": " + (numValue / scaleFactor) + unit + " !important; ";
        } else {
          styleString += prop + ": " + value + " !important; ";
        }
      }
    });

    const transformOrigin = computedStyle.getPropertyValue("transform-origin");
    if (transformOrigin) {
      styleString +=
        "transform-origin: " + transformOrigin + " !important; " +
        "-webkit-transform-origin: " + transformOrigin + " !important; ";
    }

    styleString +=
      "overflow: visible !important; max-width: none !important; " +
      "max-height: none !important; clip: auto !important; clip-path: none !important; ";

    target.style.cssText += styleString;
  }

  function deepCloneWithStyles(element, scaleFactor, heightScaleDivisor) {
    const clone = element.cloneNode(false);
    const hasTextClass = element.classList?.contains("t");
    const hasUnderscoreClass = element.classList?.contains("_");
    const shouldScaleMargin =
      element.tagName === "SPAN" &&
      element.classList?.contains("_") &&
      [...element.classList].some((cls) => /^_(?:\d+[a-z]*|[a-z]+\d*)$/i.test(cls));

    copyComputedStyle(
      element,
      clone,
      scaleFactor,
      hasTextClass,
      hasUnderscoreClass,
      heightScaleDivisor,
      4,
      shouldScaleMargin,
      scaleFactor
    );

    if (element.classList?.contains("pc")) {
      clone.style.setProperty("transform", "none", "important");
      clone.style.setProperty("-webkit-transform", "none", "important");
      clone.style.setProperty("overflow", "visible", "important");
      clone.style.setProperty("max-width", "none", "important");
      clone.style.setProperty("max-height", "none", "important");
    }

    if (element.childNodes.length === 1 && element.childNodes[0].nodeType === Node.TEXT_NODE) {
      clone.textContent = element.textContent;
      return clone;
    }

    element.childNodes.forEach((child) => {
      if (child.nodeType === Node.ELEMENT_NODE) {
        clone.appendChild(deepCloneWithStyles(child, scaleFactor, heightScaleDivisor));
      } else if (child.nodeType === Node.TEXT_NODE) {
        clone.appendChild(child.cloneNode(true));
      }
    });

    return clone;
  }

  function pageDimensionsFrom(page) {
    const pc = page.querySelector(".pc");
    let width = CLEAN_PAGE.fallbackWidth;
    let height = CLEAN_PAGE.fallbackHeight;

    if (!pc) return { width, height };

    const pcStyle = getComputedStyle(pc);
    const pcWidth = parseFloat(pcStyle.width);
    const pcHeight = parseFloat(pcStyle.height);

    if (!Number.isNaN(pcWidth) && pcWidth > 0 && !Number.isNaN(pcHeight) && pcHeight > 0) {
      return { width: pcWidth, height: pcHeight };
    }

    const rect = pc.getBoundingClientRect();
    if (rect.width > 10 && rect.height > 10) {
      width = rect.width;
      height = rect.height;
    }

    return { width, height };
  }

  function buildCleanPage(page, number) {
    const pc = page.querySelector(".pc");
    const originalImg = page.querySelector("img.bi") || page.querySelector("img");

    if (!pc && !originalImg) {
      const clone = page.cloneNode(true);
      stripKToolsUi(clone);
      normalizeCapturedVisibility(clone);
      clone.classList.add("ktools-studocu-page");
      clone.dataset.ktoolsPage = String(number);
      return clone;
    }

    const { width, height } = pageDimensionsFrom(page);
    const newPage = document.createElement("div");
    newPage.className = "ktools-studocu-page";
    newPage.dataset.ktoolsPage = String(number);
    newPage.style.position = "relative";
    newPage.style.display = "block";
    newPage.style.width = width + "px";
    newPage.style.height = height + "px";
    newPage.style.overflow = "hidden";

    if (originalImg) {
      const bgLayer = document.createElement("div");
      bgLayer.className = "ktools-studocu-layer-bg";
      bgLayer.style.cssText =
        "position:absolute;top:0;left:0;width:100%;height:100%;z-index:1;pointer-events:none;";

      const imgClone = originalImg.cloneNode(true);
      imgClone.style.cssText =
        "width:100%;height:100%;object-fit:contain;object-position:top center;" +
        "display:block;filter:none!important;-webkit-filter:none!important;" +
        "visibility:visible!important;opacity:1!important;";
      bgLayer.appendChild(imgClone);
      newPage.appendChild(bgLayer);
    }

    if (pc) {
      const textLayer = document.createElement("div");
      textLayer.className = "ktools-studocu-layer-text";
      textLayer.style.cssText =
        "position:absolute;top:0;left:0;width:100%;height:100%;z-index:10;overflow:visible !important;";

      const pcClone = deepCloneWithStyles(
        pc,
        CLEAN_PAGE.scaleFactor,
        CLEAN_PAGE.heightScaleDivisor
      );
      stripKToolsUi(pcClone);
      normalizeCapturedVisibility(pcClone);
      pcClone.querySelectorAll("img").forEach((image) => {
        image.style.display = "none";
      });

      textLayer.appendChild(pcClone);
      newPage.appendChild(textLayer);
    }

    return newPage;
  }

  function showToast(message, tone = "info") {
    document.getElementById(IDS.toast)?.remove();
    const toast = document.createElement("div");
    toast.id = IDS.toast;
    toast.dataset.tone = tone;
    toast.textContent = message;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4200);
  }

  function control(id) {
    return document.getElementById(id);
  }

  function updatePanelStatus(message, progress) {
    const status = control(IDS.status);
    const bar = control(IDS.progressBar);

    if (status) status.textContent = message;
    if (bar) bar.style.width = Math.round((progress || 0) * 100) + "%";
  }

  function sendExtensionMessage(message) {
    return new Promise((resolve, reject) => {
      if (!globalThis.chrome?.runtime?.sendMessage) {
        reject(new Error("Extension messaging is not available."));
        return;
      }

      chrome.runtime.sendMessage(message, (response) => {
        const runtimeError = chrome.runtime.lastError;
        if (runtimeError) {
          reject(new Error(runtimeError.message));
          return;
        }

        if (!response?.ok) {
          reject(new Error(response?.error || "The request failed."));
          return;
        }

        resolve(response);
      });
    });
  }

  async function captureAccessiblePages() {
    state.originalScrollY = window.scrollY;
    let initialPages = getPageNodes();

    if (!initialPages.length) {
      throw new Error("No supported Studocu document viewer was found.");
    }

    const captures = [];
    const restricted = [];
    const total = initialPages.length;

    for (let index = 0; index < total; index += 1) {
      const currentPages = getPageNodes();
      const page = currentPages[index] || initialPages[index];
      if (!page || !page.isConnected) continue;

      updatePanelStatus("Step 2: Capturing " + (index + 1) + " / " + total, (index + 1) / total);
      page.scrollIntoView({ block: "center", behavior: "auto" });
      await waitForStablePage(page);
      await sleep(80);

      const refreshedPages = getPageNodes();
      const renderedPage = refreshedPages[index] || page;
      const number = pageNumber(renderedPage, index);

      if (hasRestrictionMarker(renderedPage)) {
        restricted.push(number);
        continue;
      }

      if (!hasRenderedContent(renderedPage)) {
        restricted.push(number);
        continue;
      }

      captures.push(buildCleanPage(renderedPage, number));
    }

    window.scrollTo({ top: state.originalScrollY, behavior: "auto" });
    return { captures, restricted, total };
  }

  function closeViewer() {
    document.getElementById(IDS.viewer)?.remove();
    document.documentElement.classList.remove("ktools-studocu-view-open");
    document.body.classList.remove("ktools-studocu-printing");
  }

  function openViewer(result) {
    closeViewer();

    const overlay = document.createElement("section");
    overlay.id = IDS.viewer;
    overlay.dataset.ktoolsUi = "true";

    const toolbar = document.createElement("header");
    toolbar.className = "ktools-studocu-toolbar";

    const titleBlock = document.createElement("div");
    titleBlock.className = "ktools-studocu-title";

    const title = document.createElement("strong");
    title.textContent = "KTools Studocu PDF Exporter";

    const summary = document.createElement("span");
    summary.textContent =
      result.captures.length + " accessible page(s) ready" +
      (result.restricted.length
        ? " · " + result.restricted.length + " restricted/unavailable page(s) skipped"
        : "");

    titleBlock.append(title, summary);

    const actions = document.createElement("div");
    actions.className = "ktools-studocu-actions";

    const printButton = document.createElement("button");
    printButton.type = "button";
    printButton.className = "ktools-studocu-primary";
    printButton.textContent = "Print / Save as PDF";
    printButton.addEventListener("click", () => {
      document.body.classList.add("ktools-studocu-printing");
      window.print();
    });

    const closeButton = document.createElement("button");
    closeButton.type = "button";
    closeButton.textContent = "Close";
    closeButton.addEventListener("click", closeViewer);

    actions.append(printButton, closeButton);
    toolbar.append(titleBlock, actions);

    const pages = document.createElement("main");
    pages.className = "ktools-studocu-pages";
    result.captures.forEach((page) => pages.appendChild(page));

    overlay.append(toolbar, pages);
    document.body.appendChild(overlay);
    document.documentElement.classList.add("ktools-studocu-view-open");
    window.addEventListener(
      "afterprint",
      () => document.body.classList.remove("ktools-studocu-printing"),
      { once: true }
    );
  }

  async function startExport() {
    if (state.busy) return;
    state.busy = true;

    const downloadButton = control(IDS.downloadButton);
    downloadButton?.classList.add("is-busy");
    downloadButton?.setAttribute("disabled", "");
    document.getElementById(IDS.root)?.classList.add("open");

    try {
      updatePanelStatus("Step 2: Finding rendered pages…", 0);
      const result = await captureAccessiblePages();

      if (!result.captures.length) {
        throw new Error(
          "No unrestricted rendered pages were available. KTools does not unlock premium pages."
        );
      }

      openViewer(result);
      updatePanelStatus("Step 2: Ready to print / save as PDF.", 1);

      if (result.restricted.length) {
        showToast(
          "Skipped restricted/unavailable pages: " + result.restricted.join(", "),
          "warning"
        );
      }
    } catch (error) {
      console.error("[KTools Studocu]", error);
      showToast(error.message || "The document could not be prepared.", "error");
      updatePanelStatus(error.message || "The document could not be prepared.", 0);
    } finally {
      state.busy = false;
      downloadButton?.classList.remove("is-busy");
      downloadButton?.removeAttribute("disabled");
    }
  }

  async function clearCookiesAndReload() {
    if (state.busy) return;
    state.busy = true;

    const unblurButton = control(IDS.unblurButton);
    unblurButton?.classList.add("is-busy");
    unblurButton?.setAttribute("disabled", "");
    document.getElementById(IDS.root)?.classList.add("open");

    try {
      updatePanelStatus("Step 1: Clearing Studocu cookies…", 0.1);
      showToast("Clearing Studocu cookies…");
      const response = await sendExtensionMessage({ type: MESSAGES.clearCookies });
      updatePanelStatus("Step 1: Cleared " + response.count + " cookie(s). Reloading…", 1);
      showToast("Cleared " + response.count + " Studocu cookie(s). Reloading…", "warning");
      setTimeout(() => window.location.reload(), 800);
    } catch (error) {
      console.error("[KTools Studocu]", error);
      showToast(error.message || "Could not clear Studocu cookies.", "error");
      updatePanelStatus(error.message || "Could not clear Studocu cookies.", 0);
    } finally {
      state.busy = false;
      unblurButton?.classList.remove("is-busy");
      unblurButton?.removeAttribute("disabled");
    }
  }

  function ensureLauncher() {
    if (!getPageNodes().length) return;
    if (document.getElementById(IDS.root)) return;

    const root = document.createElement("div");
    root.id = IDS.root;
    root.dataset.ktoolsUi = "true";
    root.innerHTML =
      '<button id="' + IDS.toggle + '" type="button">STU</button>' +
      '<section id="' + IDS.panel + '">' +
        '<div class="ktools-studocu-panel-title">' +
          'Studocu tools' +
          '<a class="ktools-studocu-brand" href="https://ktools369.github.io/studocu/" target="_blank" rel="noopener">KTools ↗</a>' +
        '</div>' +
        '<div id="' + IDS.status + '" class="ktools-studocu-panel-status">' +
          'Hover panel: run Step 1 when the viewer needs a cookie reset, then Step 2 to prepare the PDF view.' +
        '</div>' +
        '<div class="ktools-studocu-steps">' +
          '<button id="' + IDS.unblurButton + '" class="ktools-studocu-step" type="button">' +
            '<span class="ktools-studocu-step-index">1</span>' +
            '<span><strong>Unblur / reset</strong><small>Clear Studocu cookies and reload this tab</small></span>' +
          '</button>' +
          '<button id="' + IDS.downloadButton + '" class="ktools-studocu-step ktools-studocu-step-primary" type="button">' +
            '<span class="ktools-studocu-step-index">2</span>' +
            '<span><strong>Download PDF</strong><small>Capture rendered pages, then print / save</small></span>' +
          '</button>' +
        '</div>' +
        '<div class="ktools-studocu-progress"><div id="' + IDS.progressBar + '"></div></div>' +
        '<div class="ktools-studocu-note">' +
          'Step 1 only resets cookies like the old popup. Step 2 uses the content script to scroll, capture available pages, and open a printable viewer.' +
        '</div>' +
      '</section>';

    document.documentElement.appendChild(root);
    control(IDS.toggle)?.addEventListener("click", () => root.classList.toggle("open"));
    control(IDS.unblurButton)?.addEventListener("click", clearCookiesAndReload);
    control(IDS.downloadButton)?.addEventListener("click", startExport);
  }

  ensureLauncher();

  const observer = new MutationObserver(() => ensureLauncher());
  observer.observe(document.documentElement, { childList: true, subtree: true });

  window.addEventListener("pagehide", () => observer.disconnect(), { once: true });
})();
