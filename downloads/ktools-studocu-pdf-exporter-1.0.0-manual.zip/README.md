# KTools Studocu PDF Exporter 1.0.0

Extension này thêm nút nổi **STU** trên trang tài liệu Studocu. Hover vào nút, hoặc click nút, để mở bảng thao tác giống format tool Scribd.

## Cách dùng

1. Mở trang tài liệu Studocu.
2. Hover nút **STU** ở cạnh phải màn hình.
3. Chọn **Step 1 - Unblur / reset** nếu cần reset cookie. Trang sẽ tự reload sau khi xóa cookie Studocu.
4. Chọn **Step 2 - Download PDF** để content script quét các trang đã render, mở viewer sạch, rồi bấm **Print / Save as PDF**.

Luồng chính vẫn do `content.js` điều khiển. `background.js` chỉ dùng cho cookie vì content script không gọi trực tiếp được `chrome.cookies`.
