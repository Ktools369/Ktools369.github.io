(() => {
  "use strict";
  if (window.top !== window || document.getElementById("dpe-root")) return;

  const root = document.createElement("div");
  root.id = "dpe-root";
  root.innerHTML = `
    <button id="dpe-toggle" type="button" title="Export PDF">PDF</button>
    <section id="dpe-panel" aria-label="PDF export options">
      <div class="dpe-title">Export Drive document <a class="dpe-brand" href="https://ktools.github.io/" target="_blank" rel="noopener">KTools ↗</a></div>
      <div id="dpe-status" class="dpe-status">Reading document information…</div>
      <div class="dpe-row"><label for="dpe-name">File name</label><input id="dpe-name" type="text" maxlength="180"></div>
      <div class="dpe-row"><label for="dpe-width">Resolution</label><select id="dpe-width">
        <option value="3200">High — up to 3200 px</option><option value="2400" selected>Balanced — up to 2400 px</option>
        <option value="1600">Low — up to 1600 px</option><option value="800">Small — up to 800 px</option>
      </select></div>
      <div class="dpe-row"><label for="dpe-quality">JPEG quality</label><select id="dpe-quality">
        <option value="0.95">Very high — 95%</option><option value="0.85" selected>Balanced — 85%</option>
        <option value="0.70">Compressed — 70%</option><option value="0.50">Highly compressed — 50%</option>
      </select></div>
      <div id="dpe-estimate" class="dpe-estimate">Estimated size: calculating…</div>
      <div class="dpe-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0"><div id="dpe-progress-bar"></div></div>
      <button id="dpe-download" type="button">Download complete PDF</button>
      <div class="dpe-note">Pages are processed locally to create your PDF and are not sent to KTools. You may switch tabs, but keep this Drive tab open.</div>
    </section>`;
  document.documentElement.appendChild(root);

  const $ = (selector) => root.querySelector(selector);
  const status = $("#dpe-status");
  const estimate = $("#dpe-estimate");
  const progress = $(".dpe-progress");
  const progressBar = $("#dpe-progress-bar");
  const downloadButton = $("#dpe-download");
  const filenameInput = $("#dpe-name");
  const widthInput = $("#dpe-width");
  const qualityInput = $("#dpe-quality");
  const XSSI_PREFIX = /^\)\]\}'\s*/;
  const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
  let metaPromise;
  let sharedPauseUntil = 0;

  function safeFilename(value) {
    const clean = String(value || "drive-document").replace(/[\\/:*?"<>|\u0000-\u001f]/g, "_")
      .replace(/\s+/g, " ").trim().slice(0, 180) || "drive-document";
    return clean.toLowerCase().endsWith(".pdf") ? clean : `${clean}.pdf`;
  }
  function formatBytes(bytes) {
    if (!Number.isFinite(bytes) || bytes <= 0) return "—";
    if (bytes >= 1024 ** 3) return `${(bytes / 1024 ** 3).toFixed(1)} GB`;
    if (bytes >= 1024 ** 2) return `${Math.round(bytes / 1024 ** 2)} MB`;
    return `${Math.round(bytes / 1024)} KB`;
  }
  function setProgress(percent) {
    const value = Math.max(0, Math.min(100, Math.round(percent || 0)));
    progressBar.style.width = `${value}%`;
    progress.setAttribute("aria-valuenow", String(value));
  }
  function reportProgress(phase, percent, ok) {
    chrome.runtime.sendMessage({ type: "dpe-progress", phase, percent, ok }).catch(() => {});
  }
  async function waitForViewerMeta(timeoutMs = 25000) {
    const started = Date.now();
    while (Date.now() - started < timeoutMs) {
      const url = performance.getEntriesByType("resource").map((entry) => entry.name)
        .find((name) => name.includes("/viewer/meta"));
      if (url) return url;
      await sleep(300);
    }
    throw new Error("Viewer metadata was not found. Reload the Drive page and try again.");
  }
  async function readViewerMeta(metaUrl) {
    const response = await fetch(metaUrl, { credentials: "include" });
    if (!response.ok) throw new Error(`Drive returned HTTP ${response.status} while reading metadata.`);
    const data = JSON.parse((await response.text()).replace(XSSI_PREFIX, ""));
    const pageCount = Number(data.pages) || 0;
    if (pageCount < 1) throw new Error("Drive did not provide a valid page count.");
    return { metaUrl, pageCount, maxWidth: Number(data.maxPageWidth) || 3200 };
  }
  function getMeta() {
    if (!metaPromise) metaPromise = waitForViewerMeta().then(readViewerMeta).catch((error) => {
      metaPromise = undefined;
      throw error;
    });
    return metaPromise;
  }
  function viewerImageUrl(metaUrl, page, width) {
    const url = new URL(metaUrl);
    url.pathname = url.pathname.replace(/\/meta$/, "/img");
    url.searchParams.set("page", String(page));
    url.searchParams.set("w", String(width));
    url.searchParams.set("skiphighlight", "true");
    url.searchParams.delete("webp");
    return url.toString();
  }
  async function updateEstimate() {
    estimate.textContent = "Estimated size: calculating…";
    try {
      const meta = await getMeta();
      const width = Math.min(meta.maxWidth, Number(widthInput.value));
      const quality = Number(qualityInput.value);
      const perPage = 0.54 * 1024 ** 2 * (width / 2400) ** 2 * (quality / 0.92);
      estimate.textContent = `Estimated size: ~${formatBytes(perPage * meta.pageCount)} · ${meta.pageCount} pages`;
      status.textContent = `${meta.pageCount} pages detected · maximum source width ${meta.maxWidth}px.`;
    } catch (error) {
      estimate.textContent = "Estimated size unavailable";
      status.textContent = error.message;
    }
  }
  async function blobToJpegBytes(blob, quality) {
    const bitmap = await createImageBitmap(blob);
    try {
      const canvas = typeof OffscreenCanvas === "function" ? new OffscreenCanvas(bitmap.width, bitmap.height)
        : Object.assign(document.createElement("canvas"), { width: bitmap.width, height: bitmap.height });
      const ctx = canvas.getContext("2d", { alpha: false });
      ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, bitmap.width, bitmap.height); ctx.drawImage(bitmap, 0, 0);
      const jpeg = canvas.convertToBlob ? await canvas.convertToBlob({ type: "image/jpeg", quality })
        : await new Promise((resolve, reject) => canvas.toBlob(
          (result) => result ? resolve(result) : reject(new Error("JPEG encoding failed.")), "image/jpeg", quality));
      return { data: new Uint8Array(await jpeg.arrayBuffer()), width: bitmap.width, height: bitmap.height };
    } finally { bitmap.close(); }
  }

  async function fetchViewerPage(metaUrl, page, width, quality, attempts = 3) {
    let lastError;
    for (let attempt = 0; attempt < attempts; attempt++) {
      const wait = sharedPauseUntil - Date.now();
      if (wait > 0) await sleep(wait);
      try {
        const response = await fetch(viewerImageUrl(metaUrl, page, width), { credentials: "include" });
        if (response.ok) return await blobToJpegBytes(await response.blob(), quality);
        if (response.status !== 429 && response.status < 500) throw new Error(`Page ${page + 1}: Drive returned HTTP ${response.status}.`);
        lastError = new Error(`Page ${page + 1}: Drive temporarily returned HTTP ${response.status}.`);
      } catch (error) {
        lastError = error;
        if (/HTTP (400|401|403|404)/.test(String(error?.message))) throw error;
      }
      const backoff = Math.min(500 * 2 ** attempt, 3500) + Math.floor(Math.random() * 350);
      sharedPauseUntil = Math.max(sharedPauseUntil, Date.now() + backoff);
    }
    throw lastError || new Error(`Page ${page + 1} could not be downloaded.`);
  }
  async function fetchMissingPages(meta, pages, width, quality, onProgress) {
    const queue = pages.map((page, index) => page ? null : index).filter((index) => index !== null);
    let cursor = 0;
    async function worker() {
      while (cursor < queue.length) {
        const index = queue[cursor++];
        try { pages[index] = { ...(await fetchViewerPage(meta.metaUrl, index, width, quality)), order: index }; }
        catch (error) { console.warn("Drive PDF Exporter:", error); }
        onProgress();
      }
    }
    await Promise.all(Array.from({ length: Math.min(4, queue.length) }, worker));
  }
  async function buildPdfBlob(pages, onProgress) {
    const encoder = new TextEncoder();
    const chunks = [];
    const offsets = [];
    let byteLength = 0;
    const push = (value) => {
      const bytes = typeof value === "string" ? encoder.encode(value) : value;
      chunks.push(bytes);
      byteLength += bytes.byteLength;
    };
    const beginObject = (id) => {
      offsets[id] = byteLength;
      push(`${id} 0 obj\n`);
    };
    const objectCount = 2 + pages.length * 3;

    push("%PDF-1.7\n");
    push(new Uint8Array([0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a]));
    beginObject(1);
    push("<< /Type /Catalog /Pages 2 0 R >>\nendobj\n");
    beginObject(2);
    const pageRefs = pages.map((_, index) => `${3 + index * 3} 0 R`).join(" ");
    push(`<< /Type /Pages /Count ${pages.length} /Kids [${pageRefs}] >>\nendobj\n`);

    for (let i = 0; i < pages.length; i++) {
      const page = pages[i];
      if (!page || !Number.isFinite(page.width) || !Number.isFinite(page.height) || !page.data?.byteLength) {
        throw new Error(`Page ${i + 1} contains invalid image data.`);
      }
      const pageId = 3 + i * 3;
      const contentId = pageId + 1;
      const imageId = pageId + 2;
      const widthPt = (page.width * 0.75).toFixed(2);
      const heightPt = (page.height * 0.75).toFixed(2);
      const drawing = `q\n${widthPt} 0 0 ${heightPt} 0 0 cm\n/Im0 Do\nQ\n`;
      const drawingBytes = encoder.encode(drawing);

      beginObject(pageId);
      push(`<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${widthPt} ${heightPt}] /Resources << /XObject << /Im0 ${imageId} 0 R >> >> /Contents ${contentId} 0 R >>\nendobj\n`);
      beginObject(contentId);
      push(`<< /Length ${drawingBytes.byteLength} >>\nstream\n`);
      push(drawingBytes);
      push("endstream\nendobj\n");
      beginObject(imageId);
      push(`<< /Type /XObject /Subtype /Image /Width ${page.width} /Height ${page.height} /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ${page.data.byteLength} >>\nstream\n`);
      push(page.data);
      push("\nendstream\nendobj\n");

      if (i % 8 === 0 || i === pages.length - 1) {
        onProgress(i + 1, pages.length);
        await sleep(0);
      }
    }

    const xrefOffset = byteLength;
    push(`xref\n0 ${objectCount + 1}\n`);
    push("0000000000 65535 f \n");
    for (let id = 1; id <= objectCount; id++) push(`${String(offsets[id]).padStart(10, "0")} 00000 n \n`);
    push(`trailer\n<< /Size ${objectCount + 1} /Root 1 0 R >>\nstartxref\n${xrefOffset}\n%%EOF\n`);
    return new Blob(chunks, { type: "application/pdf" });
  }
  async function savePages(pages, onProgress) {
    const blob = await buildPdfBlob(pages, onProgress);
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = safeFilename(filenameInput.value);
    link.style.display = "none";
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    return blob.size;
  }
  async function downloadCompletePdf() {
    downloadButton.disabled = widthInput.disabled = qualityInput.disabled = true;
    setProgress(0); sharedPauseUntil = 0; reportProgress("loading", 0);
    try {
      const meta = await getMeta();
      const quality = Number(qualityInput.value);
      const requestedWidth = Math.min(meta.maxWidth, Number(widthInput.value));
      const widths = [...new Set([requestedWidth, 2400, 1600, 800])].filter((w) => w <= requestedWidth).sort((a, b) => b - a);
      // Use real null entries: Array#every/map skip uninitialized sparse slots.
      const pages = Array.from({ length: meta.pageCount }, () => null);
      let downloadedBytes = 0;
      for (const width of widths) {
        if (pages.every(Boolean)) break;
        await fetchMissingPages(meta, pages, width, quality, () => {
          const completed = pages.filter(Boolean);
          downloadedBytes = completed.reduce((sum, page) => sum + page.data.byteLength, 0);
          const done = completed.length;
          setProgress(done / meta.pageCount * 90);
          status.textContent = `Downloading ${done}/${meta.pageCount} pages · ${width}px`;
          if (done) estimate.textContent = `Projected final size: ~${formatBytes(downloadedBytes / done * meta.pageCount)}`;
          reportProgress("loading", Math.round(done / meta.pageCount * 100));
        });
        if (!pages.every(Boolean)) await sleep(1200);
      }
      const missing = pages.map((page, index) => page ? null : index + 1).filter(Boolean);
      if (missing.length) throw new Error(`Missing ${missing.length}/${meta.pageCount} pages: ${missing.slice(0, 12).join(", ")}${missing.length > 12 ? "…" : ""}`);
      status.textContent = "Building PDF…"; reportProgress("merging");
      const finalSize = await savePages(pages, (done, total) => { setProgress(90 + done / total * 10); status.textContent = `Building PDF ${done}/${total} pages…`; });
      setProgress(100); status.textContent = `Complete · ${meta.pageCount} pages downloaded.`;
      estimate.textContent = `Final PDF size: ${formatBytes(finalSize)}`;
      reportProgress("done", 100, true);
    } catch (error) {
      console.error("Drive PDF Exporter:", error);
      status.textContent = `Download failed: ${error?.message || "Unknown error"}`;
      reportProgress("done", undefined, false);
    } finally { downloadButton.disabled = widthInput.disabled = qualityInput.disabled = false; }
  }

  filenameInput.value = safeFilename(document.querySelector('meta[itemprop="name"]')?.content || document.title.replace(/\s+-\s+Google Drive\s*$/i, ""));
  $("#dpe-toggle").addEventListener("click", () => root.classList.toggle("dpe-open"));
  widthInput.addEventListener("change", updateEstimate);
  qualityInput.addEventListener("change", updateEstimate);
  downloadButton.addEventListener("click", downloadCompletePdf);
  updateEstimate();
})();
