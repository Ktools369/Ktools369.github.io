# KTools Scribd PDF Exporter 1.0.1

This offline extension captures only document pages that Scribd has already rendered for the current user and creates an image-based PDF locally.

On a `/document/{id}/...` page it shows only one floating **Go Download** button. Clicking it opens `/embeds/{id}/content?start_page=1&view_mode=scroll`. The **PDF** button and its hover export options are created only inside that reader.

It does not supply access keys, unlock previews, automate login, use third-party downloader websites or bypass access controls. Use it only where you own the content or have permission to make a copy.
