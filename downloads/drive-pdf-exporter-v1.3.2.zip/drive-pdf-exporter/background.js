"use strict";

let clearTimer;

chrome.runtime.onMessage.addListener((message) => {
  if (message?.type !== "dpe-progress") return;
  clearTimeout(clearTimer);

  if (message.phase === "done") {
    chrome.action.setBadgeText({ text: message.ok ? "✓" : "!" });
    chrome.action.setBadgeBackgroundColor({ color: message.ok ? "#137333" : "#c5221f" });
    clearTimer = setTimeout(() => chrome.action.setBadgeText({ text: "" }), 8000);
    return;
  }

  const text = Number.isFinite(message.percent) ? String(message.percent) : "…";
  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({ color: "#1a73e8" });
});
