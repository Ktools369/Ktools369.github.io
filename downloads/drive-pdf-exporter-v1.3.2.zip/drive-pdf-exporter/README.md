# Drive Image PDF Exporter

A Chrome Manifest V3 extension that downloads authorized Google Drive viewer
pages in the background and combines them into an image-based PDF.

## Installation

1. Extract the ZIP archive.
2. Open `chrome://extensions` in Chrome.
3. Enable **Developer mode**.
4. Select **Load unpacked**.
5. Choose the extracted `drive-pdf-exporter` folder.
6. Reload any Drive document tab that was already open.

## Usage

1. Open a document in Google Drive.
2. Hover over or click the blue **PDF** button on the right.
3. Choose the file name, resolution and JPEG quality. The estimated output
   size updates whenever the configuration changes.
4. Click **Download complete PDF**. A progress bar shows downloading and PDF
   assembly progress.
5. You may switch tabs while the download runs. Keep the Drive tab open.

## Notes

- Drive can change its viewer endpoints or metadata structure at any time.
- Very long or high-resolution documents can consume substantial memory.
- The displayed file size is an estimate and varies with page content.
- The output is an image-based PDF without a searchable text layer.
- Maximum quality is limited by the page images served by Drive.
- Only use this tool for documents you own or are authorized to save.

The extension does not send page images or document contents to an external
server. It assembles the PDF locally from the downloaded JPEG page data.
